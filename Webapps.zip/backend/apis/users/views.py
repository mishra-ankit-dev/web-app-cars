from .detail.views import UserDetailView, UsersDetailsView
