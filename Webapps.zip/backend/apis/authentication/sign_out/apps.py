from django.apps import AppConfig


class SignOutConfig(AppConfig):
    name = 'sign_out'
