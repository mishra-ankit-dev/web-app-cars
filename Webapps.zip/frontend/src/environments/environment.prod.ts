export const environment = {
  production: true,
  API_BASE_URL: 'http://localhost:8000/api',
  ADMIN_URL: 'http://localhost:8000/admin/',
};
