from django.apps import AppConfig


class UsersConfig(AppConfig):
    name = 'apis.users'
