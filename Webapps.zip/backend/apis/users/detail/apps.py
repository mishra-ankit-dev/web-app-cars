from django.apps import AppConfig


class UserDetailConfig(AppConfig):
    name = 'api.users.detail'
