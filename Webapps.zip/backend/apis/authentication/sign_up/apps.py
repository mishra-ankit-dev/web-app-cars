from django.apps import AppConfig


class SignUpConfig(AppConfig):
    name = 'sign_up'
